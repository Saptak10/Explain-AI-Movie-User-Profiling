# Study data export -- codebook

Every table is one CSV file in this export. `round` and `version` appear
in most of them -- read this section first.

## `version` (A/B condition)
`O` = Transparent AI (explanations + genre editing shown).
`N` = Standard AI (recommendations only, no explanations or editing).
Assigned once per account at registration (`users.version`, permanent).
An admin can *preview* the other condition for the same account mid-session
via a dev-only toggle -- when that happens, `users.active_version` changes
and every event from that point on is tagged with the new active condition,
not the original permanent one. `condition_switches.csv` logs every time
this happened. Compare a user's `version` (users.csv) against the `version`
column on their individual event rows if you need to detect this.

## `round`
Counts rate/recommend cycles *within the currently active condition*,
resetting to 0 every time the condition is switched:
  - `0` = the initial rating phase, before any recommendation list has
    been generated yet (ratings submitted here get round = 0).
  - `1` = after the first recommendation list was generated. Any edits
    made in response to that list, and the ratings submitted afterward
    (if any), are logged as round = 1.
  - `2`, `3`, ... = after each subsequent recommend call (e.g. the list
    regenerated after applying an edit).
`round` on a `recommendations.csv` row is the round *that list itself
represents* (i.e. it already reflects the call that produced it).

## Files

### users.csv
One row per account. `version` = permanent assigned condition.
`active_version`/`current_round` = condition/round currently in effect
(only differs from `version` if a dev preview switch happened).
`sus_score` = final 0-100 System Usability Scale score (Brooke 1996
formula), null until all 10 questions are answered.

### demographics.csv
Self-reported age group, degree/job, and prior Netflix experience,
collected together with the SUS survey.

### condition_switches.csv
One row per manual A/B condition switch. Use this to split a single
account's other event rows into "before"/"after" a switch if needed.

### shown_movies.csv
One row per movie that appeared in the rate-page's random sample pool,
in whichever round/condition it was shown. This is the full candidate
pool the user *could* have rated, not just the ones they did -- compare
against rating_events.csv to see selection rate.

### ratings.csv
One row per (user, movie) -- each user's *current* rating for every
movie they've rated, straight from the table that actually drives their
recommendations. Always complete. Use this for "which movies did each
user rate" and "what rating did they give it"; use rating_events.csv
(below) only if you need the round/condition/timing of when a rating
was submitted.

### rating_events.csv
One row per rating action (a re-rate of the same movie creates a new
row here, unlike ratings.csv above, which only keeps each movie's
latest rating). **Only complete for ratings submitted after this
logging was added** -- any session that rated movies before then has
real ratings in ratings.csv but no corresponding rows here, so
user_summary.csv's ratings_submitted_count is computed from ratings.csv,
not this file.

### profile_edits.csv
One row per genre touched by one edit action (clicking a boost/suppress
button and then Apply/Get Recommendations). `delta` is the numeric
change on the model's [0,1] genre scale (-0.5 to +0.5); `level` is its
human label (`strong_decrease`, `slight_decrease`, `neutral`,
`slight_increase`, `strong_increase`). `source` is `movie_card` (edited
from a specific recommendation's "Edit Preferences" panel) or
`profile_page` (edited from the main Profile page). A user re-editing
the same genre twice produces two rows here, even though only the
latest value is kept in the live app's own state.

### recommendations.csv
One row per movie per recommendation list per recommend call --
i.e. a full impression log. `list_type` is `top_rated` (highest raw
predicted score, may include broadly popular titles) or `for_you`
(ranked by personalization lift over a genre-neutral baseline, favors
movies specifically matched to this user). `trigger_type` is `initial`
(a plain, un-edited recommend call) or `edited` (generated right after
applying a genre override). `rank` is 1-indexed position within that
list. `score` is the model's raw predicted rating (0-5 scale).

### sus_responses.csv
One row per individual SUS question response (1-5 Likert scale).
`question_idx` is 0-indexed into the standard 10-question SUS
instrument; odd/even index determines whether the item is
reverse-scored in the total (see users.sus_score for the final result).

### user_summary.csv
One row per user, aggregating the tables above into the counts most
likely needed directly for the paper's results section: total ratings,
total profile edits (and the movie-card vs. profile-page split),
distinct genres touched, and number of distinct recommendation rounds
generated, alongside the SUS score.
